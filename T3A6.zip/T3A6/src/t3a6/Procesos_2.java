package t3a6;

public class Procesos_2 {
    
    private double nomina;
    
    public Procesos_2 (){}

    public Procesos_2 (double nomina) {
        this.nomina = nomina;
    }

    public double getNomina() {
        return nomina;
    }

    public void setNomina(double nomina) {
        this.nomina = nomina;
    }

    @Override
    public String toString() {
        return "su nomina por las empresas seria " + nomina;
    }   
}

